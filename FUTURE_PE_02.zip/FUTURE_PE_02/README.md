# AI Content Marketing using UGC Ads

This repository showcases prompt engineering for UGC ads.
