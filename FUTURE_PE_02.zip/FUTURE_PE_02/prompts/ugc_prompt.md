# UGC Prompt
Create a 30-second authentic UGC advertisement for EcoGlow Water Bottle.