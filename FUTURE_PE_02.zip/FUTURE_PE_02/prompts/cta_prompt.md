# CTA Prompt
Generate 15 action-oriented CTAs.