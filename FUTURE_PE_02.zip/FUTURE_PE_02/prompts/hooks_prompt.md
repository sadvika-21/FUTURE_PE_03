# Hooks Prompt
Generate 10 engaging hooks under 12 words.