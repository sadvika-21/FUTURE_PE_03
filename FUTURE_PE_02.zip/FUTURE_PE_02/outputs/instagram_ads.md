# Instagram Ad
Hook: My favorite bottle just got better!
CTA: Shop now.