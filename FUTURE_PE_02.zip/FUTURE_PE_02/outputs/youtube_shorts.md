# YouTube Shorts
Scene 1: Problem
Scene 2: Solution
Scene 3: CTA